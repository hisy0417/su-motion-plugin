// MotionBridge v4 — code.js
figma.showUI(__html__, { width: 960, height: 600, title: 'MotionBridge', themeColors: true });

// 리사이즈 허용
figma.ui.onresize = (size) => {
  figma.ui.resize(size.width, size.height);
};

// ── Helpers ──────────────────────────────────────────────────
function getData(key) {
  try { var r = figma.root.getPluginData(key); return r ? JSON.parse(r) : null; }
  catch(e) { return null; }
}
function setData(key, val) {
  try { figma.root.setPluginData(key, JSON.stringify(val)); } catch(e) {}
}

// ── Scan: 프로토타입 연결된 Frame만 ──────────────────────────
function scanConnectedFrames() {
  var frames = [];
  var connections = [];
  var frameMap = {};

  function walk(node) {
    try {
      var isFrame = node.type === 'FRAME' || node.type === 'COMPONENT' || node.type === 'SECTION';
      if (isFrame) {
        var bb = null;
        try { bb = node.absoluteBoundingBox; } catch(e) {}
        frameMap[node.id] = node.name;
        // 프로토타입 연결이 있는 Frame만 추가
        if (node.reactions && node.reactions.length > 0) {
          node.reactions.forEach(function(r, idx) {
            if (r.action && r.action.type === 'NODE' && r.action.destinationId) {
              frames.push({
                id: node.id,
                name: node.name,
                w: bb ? bb.width : (node.width || 375),
                h: bb ? bb.height : (node.height || 812),
                x: bb ? bb.x : 0,
                y: bb ? bb.y : 0,
              });
              connections.push({
                id: node.id + '__' + r.action.destinationId + '__' + idx,
                fromId: node.id,
                fromName: node.name,
                toId: r.action.destinationId,
                toName: '',
                trigger: r.trigger ? r.trigger.type : 'ON_CLICK',
                tokenId: null,
              });
            }
          });
        }
      }
      if (node.children) node.children.forEach(walk);
    } catch(e) {}
  }

  try { figma.currentPage.children.forEach(walk); } catch(e) {}

  // dedupe frames
  var seen = {};
  frames = frames.filter(function(f) {
    if (seen[f.id]) return false;
    seen[f.id] = true;
    return true;
  });

  // fill toName + restore saved token
  connections.forEach(function(c) {
    c.toName = frameMap[c.toId] || 'Unknown';
    var saved = getData('conn_' + c.id);
    if (saved && saved.tokenId) c.tokenId = saved.tokenId;
  });

  return { frames: frames, connections: connections };
}

// ── Get layers from frame ─────────────────────────────────────
function getFrameLayers(frameId) {
  var layers = [];
  try {
    var node = figma.getNodeById(frameId);
    if (!node || !node.children) return layers;
    function collect(n, depth) {
      if (depth > 3) return;
      try {
        var bb = null;
        try { bb = n.absoluteBoundingBox; } catch(e) {}
        var parentBb = null;
        try { parentBb = node.absoluteBoundingBox; } catch(e) {}
        layers.push({
          id: n.id,
          name: n.name,
          type: n.type,
          x: bb && parentBb ? Math.round(bb.x - parentBb.x) : 0,
          y: bb && parentBb ? Math.round(bb.y - parentBb.y) : 0,
          w: bb ? Math.round(bb.width) : 100,
          h: bb ? Math.round(bb.height) : 100,
          opacity: typeof n.opacity === 'number' ? n.opacity : 1,
          rotation: typeof n.rotation === 'number' ? n.rotation : 0,
          depth: depth,
        });
        if (n.children && depth < 2) {
          n.children.forEach(function(c) { collect(c, depth + 1); });
        }
      } catch(e) {}
    }
    node.children.forEach(function(c) { collect(c, 0); });
  } catch(e) {}
  return layers;
}

// ── Apply token to prototype transition ──────────────────────
function applyToken(connectionId, token) {
  try {
    var parts = connectionId.split('__');
    var fromId = parts[0];
    var reactionIdx = parseInt(parts[2] || '0', 10);
    var node = figma.getNodeById(fromId);
    if (!node || !node.reactions) return false;

    var easing = token.isSpring
      ? { type: 'EASE_OUT' }
      : { type: 'CUSTOM_CUBIC_BEZIER',
          easingFunctionCubicBezier: {
            x1: token.bezier[0], y1: token.bezier[1],
            x2: token.bezier[2], y2: token.bezier[3]
          }};
    var dur = (token.durationMs || 300) / 1000;

    // 기존 reactions를 완전히 새 배열로 재조립 (frozen 객체 직접 수정 방지)
    var newReactions = node.reactions.map(function(r, idx) {
      if (idx !== reactionIdx) return r;
      // transition이 있으면 교체, 없으면 DISSOLVE로 새로 생성
      var prevTransition = (r.action && r.action.transition) ? r.action.transition : {};
      return {
        trigger: r.trigger,
        action: {
          type: r.action ? r.action.type : 'NODE',
          destinationId: r.action ? r.action.destinationId : null,
          navigation: r.action ? r.action.navigation : 'NAVIGATE',
          preserveScrollPosition: r.action ? (r.action.preserveScrollPosition || false) : false,
          transition: {
            type: prevTransition.type || 'DISSOLVE',
            easing: easing,
            duration: dur,
          }
        }
      };
    });

    // reaction이 아예 없으면 새로 만들기
    if (newReactions.length === 0) {
      newReactions = [{
        trigger: { type: 'ON_CLICK' },
        action: {
          type: 'NODE',
          destinationId: null,
          navigation: 'NAVIGATE',
          preserveScrollPosition: false,
          transition: { type: 'DISSOLVE', easing: easing, duration: dur }
        }
      }];
    }

    node.reactions = newReactions;
    return true;
  } catch(e) { console.error('applyToken error:', e); return false; }
}

// ── Generate Motion Guide on canvas ──────────────────────────
async function generateGuide(frameId, motionData) {
  try {
    var frameNode = figma.getNodeById(frameId);
    if (!frameNode) return;

    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });

    var gf = figma.createFrame();
    gf.name = '🎬 Motion Guide — ' + frameNode.name;
    gf.x = frameNode.x + (frameNode.width || 375) + 80;
    gf.y = frameNode.y;
    gf.layoutMode = 'VERTICAL';
    gf.primaryAxisSizingMode = 'AUTO';
    gf.counterAxisSizingMode = 'FIXED';
    gf.resize(560, 60);
    gf.paddingLeft = 20; gf.paddingRight = 20;
    gf.paddingTop = 20; gf.paddingBottom = 20;
    gf.itemSpacing = 6;
    gf.cornerRadius = 12;
    gf.fills = [{ type: 'SOLID', color: { r: 0.09, g: 0.09, b: 0.11 } }];

    function addText(str, r, g, b, size, bold) {
      var t = figma.createText();
      t.fontName = { family: 'Inter', style: bold ? 'Bold' : 'Regular' };
      t.fontSize = size || 11;
      t.characters = String(str);
      t.fills = [{ type: 'SOLID', color: { r: r, g: g, b: b } }];
      t.resize(520, t.height);
      return t;
    }

    gf.appendChild(addText('Motion Guide — ' + frameNode.name, 0.95, 0.95, 0.97, 14, true));

    var div = figma.createRectangle();
    div.resize(520, 1);
    div.fills = [{ type: 'SOLID', color: { r: 0.22, g: 0.22, b: 0.26 } }];
    gf.appendChild(div);

    if (motionData && motionData.triggers) {
      motionData.triggers.forEach(function(trigger) {
        gf.appendChild(addText('Trigger: ' + trigger.type.toUpperCase(), 0.80, 0.60, 0.18, 11, true));
        (trigger.layers || []).forEach(function(lm) {
          try {
            var row = figma.createFrame();
            row.layoutMode = 'HORIZONTAL';
            row.primaryAxisSizingMode = 'FIXED';
            row.counterAxisSizingMode = 'AUTO';
            row.resize(520, 10);
            row.itemSpacing = 12;
            row.paddingLeft = 10; row.paddingRight = 10;
            row.paddingTop = 6; row.paddingBottom = 6;
            row.cornerRadius = 4;
            row.fills = [{ type: 'SOLID', color: { r: 0.13, g: 0.13, b: 0.16 } }];

            function cell(str, r, g, b, w) {
              var t = figma.createText();
              t.fontName = { family: 'Inter', style: 'Regular' };
              t.fontSize = 10;
              t.characters = String(str);
              t.fills = [{ type: 'SOLID', color: { r: r, g: g, b: b } }];
              t.resize(w, t.height);
              row.appendChild(t);
            }

            cell(lm.layerName || '—', 0.75, 0.85, 1.0, 130);
            cell(lm.tokenName || '—', 0.50, 0.70, 1.0, 200);
            cell((lm.durationMs || '?') + 'ms  delay ' + (lm.delayMs || 0) + 'ms', 0.20, 0.78, 0.68, 140);
            gf.appendChild(row);
          } catch(e) {}
        });
      });
    }

    figma.currentPage.selection = [gf];
    figma.viewport.scrollAndZoomIntoView([gf]);
    figma.notify('✨ Motion Guide generated!');
  } catch(e) {
    figma.notify('Guide error: ' + String(e));
  }
}

// ── Message handler ───────────────────────────────────────────
figma.ui.onmessage = async function(msg) {
  if (!msg || !msg.type) return;
  try {

    if (msg.type === 'INIT') {
      var data = scanConnectedFrames();
      var sel = figma.currentPage.selection[0];
      figma.ui.postMessage({
        type: 'INIT_DATA',
        frames: data.frames,
        connections: data.connections,
        selectedId: sel ? sel.id : null,
        selectedName: sel ? sel.name : null,
      });
    }

    else if (msg.type === 'SCAN') {
      var data = scanConnectedFrames();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames: data.frames, connections: data.connections });
    }

    else if (msg.type === 'LOAD_FRAME') {
      var layers = getFrameLayers(msg.frameId);
      var saved = getData('frame_motion_' + msg.frameId);
      figma.ui.postMessage({ type: 'FRAME_DATA', frameId: msg.frameId, layers: layers, motionData: saved });
    }

    else if (msg.type === 'SAVE_MOTION') {
      setData('frame_motion_' + msg.frameId, msg.motionData);
      figma.notify('Saved.');
    }

    else if (msg.type === 'APPLY_TOKEN') {
      var ok = applyToken(msg.connectionId, msg.token);
      setData('conn_' + msg.connectionId, { tokenId: msg.token.id });
      var data = scanConnectedFrames();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames: data.frames, connections: data.connections });
      if (ok) figma.notify('Applied: ' + msg.token.name);
    }

    else if (msg.type === 'GENERATE_GUIDE') {
      await generateGuide(msg.frameId, msg.motionData);
    }

    else if (msg.type === 'SELECT_NODE') {
      try {
        var n = figma.getNodeById(msg.nodeId);
        if (n) { figma.currentPage.selection = [n]; figma.viewport.scrollAndZoomIntoView([n]); }
      } catch(e) {}
    }

    else if (msg.type === 'RESIZE') {
      try { figma.ui.resize(msg.width, msg.height); } catch(e) {}
    }

  } catch(e) {
    console.error('onmessage error:', e);
    figma.notify('Error: ' + String(e));
  }
};

// ── Events ────────────────────────────────────────────────────
figma.on('selectionchange', function() {
  try {
    var sel = figma.currentPage.selection[0];
    if (sel) {
      figma.ui.postMessage({ type: 'SELECTION', id: sel.id, name: sel.name, type_: sel.type });
    }
  } catch(e) {}
});
