// MotionBridge v3 — code.js
// Defensive: every Figma API call is wrapped in try/catch

// ── ST Motion Tokens ──────────────────────────────────────────
var ST_TOKENS = [
  { id:'st-std-int-basic',    name:'st.standard.interactive.basic',     dna:'standard',   category:'interactive', variant:'basic',    easingName:'SineOut33',   bezier:[0.17,0.17,0.67,1], durationMs:100,  isSpring:false },
  { id:'st-std-int-smooth',   name:'st.standard.interactive.smooth',    dna:'standard',   category:'interactive', variant:'smooth',   easingName:'SineOut50',   bezier:[0.17,0.17,0.50,1], durationMs:200,  isSpring:false },
  { id:'st-std-int-emphasis', name:'st.standard.interactive.emphasis',  dna:'standard',   category:'interactive', variant:'emphasis', easingName:'SineOut70',   bezier:[0.17,0.17,0.30,1], durationMs:300,  isSpring:false },
  { id:'st-std-tra-basic',    name:'st.standard.transition.basic',      dna:'standard',   category:'transition',  variant:'basic',    easingName:'SineInOut33', bezier:[0.33,0,0.67,1],    durationMs:250,  isSpring:false },
  { id:'st-std-tra-smooth',   name:'st.standard.transition.smooth',     dna:'standard',   category:'transition',  variant:'smooth',   easingName:'SineInOut50', bezier:[0.33,0,0.50,1],    durationMs:350,  isSpring:false },
  { id:'st-std-tra-emphasis', name:'st.standard.transition.emphasis',   dna:'standard',   category:'transition',  variant:'emphasis', easingName:'SineInOut70', bezier:[0.33,0,0.30,1],    durationMs:450,  isSpring:false },
  { id:'st-exp-int-basic',    name:'st.expressive.interactive.basic',   dna:'expressive', category:'interactive', variant:'basic',    easingName:'Spring',      bezier:null,               durationMs:null, isSpring:true,  spring:{ stiffness:361, damping:1.0 } },
  { id:'st-exp-int-smooth',   name:'st.expressive.interactive.smooth',  dna:'expressive', category:'interactive', variant:'smooth',   easingName:'SineIn60',    bezier:[0.60,0,0.83,0.83], durationMs:300,  isSpring:false },
  { id:'st-exp-int-emphasis', name:'st.expressive.interactive.emphasis',dna:'expressive', category:'interactive', variant:'emphasis', easingName:'SineIn70',    bezier:[0.70,0,0.83,0.83], durationMs:400,  isSpring:false },
  { id:'st-exp-tra-basic',    name:'st.expressive.transition.basic',    dna:'expressive', category:'transition',  variant:'basic',    easingName:'SineIn50',    bezier:[0.50,0,0.83,0.83], durationMs:350,  isSpring:false },
  { id:'st-exp-tra-smooth',   name:'st.expressive.transition.smooth',   dna:'expressive', category:'transition',  variant:'smooth',   easingName:'SineInOut60', bezier:[0.33,0,0.40,1],    durationMs:450,  isSpring:false },
  { id:'st-exp-tra-emphasis', name:'st.expressive.transition.emphasis', dna:'expressive', category:'transition',  variant:'emphasis', easingName:'SineInOut80', bezier:[0.33,0,0.20,1],    durationMs:600,  isSpring:false },
  { id:'st-exp-exp-basic',    name:'st.expressive.expressive.basic',    dna:'expressive', category:'expressive',  variant:'basic',    easingName:'SineOut80',   bezier:[0.17,0.17,0.20,1], durationMs:500,  isSpring:false },
  { id:'st-exp-exp-smooth',   name:'st.expressive.expressive.smooth',   dna:'expressive', category:'expressive',  variant:'smooth',   easingName:'SineIn80',    bezier:[0.80,0,0.83,0.83], durationMs:700,  isSpring:false },
  { id:'st-exp-exp-emphasis', name:'st.expressive.expressive.emphasis', dna:'expressive', category:'expressive',  variant:'emphasis', easingName:'SineInOut90', bezier:[0.33,0,0.10,1],    durationMs:900,  isSpring:false }
];

var NS = 'motionbridge';

// ── Safe storage helpers ──────────────────────────────────────
function safeGetPluginData(key) {
  try { return figma.root.getPluginData(key) || ''; }
  catch(e) { return ''; }
}
function safeSetPluginData(key, val) {
  try { figma.root.setPluginData(key, val); }
  catch(e) { console.error('setPluginData error:', e); }
}

function getTokens() {
  try {
    var raw = safeGetPluginData('mb_tokens');
    if (raw) return JSON.parse(raw);
  } catch(e) {}
  return ST_TOKENS;
}
function saveTokens(tokens) {
  safeSetPluginData('mb_tokens', JSON.stringify(tokens));
}
function getFrameData(frameId) {
  try {
    var raw = safeGetPluginData('mb_frame_' + frameId);
    if (raw) return JSON.parse(raw);
  } catch(e) {}
  return null;
}
function saveFrameData(data) {
  safeSetPluginData('mb_frame_' + data.frameId, JSON.stringify(data));
}
function getConnData(connId) {
  try {
    var raw = safeGetPluginData('mb_conn_' + connId);
    if (raw) return JSON.parse(raw);
  } catch(e) {}
  return null;
}
function saveConnData(data) {
  safeSetPluginData('mb_conn_' + data.id, JSON.stringify(data));
}

// ── Scan Figma file ───────────────────────────────────────────
function scanFlowData() {
  var frames = [];
  var connections = [];

  function walkNode(node) {
    try {
      if (node.type === 'FRAME' || node.type === 'COMPONENT') {
        var motionData = getFrameData(node.id);
        var motionCount = 0;
        if (motionData && motionData.triggers) {
          motionData.triggers.forEach(function(t) {
            motionCount += (t.layers ? t.layers.length : 0);
          });
        }

        var bbox = null;
        try { bbox = node.absoluteBoundingBox; } catch(e) {}

        frames.push({
          id: node.id,
          name: node.name,
          motionCount: motionCount,
          x: bbox ? bbox.x : 0,
          y: bbox ? bbox.y : 0,
          width: node.width || 100,
          height: node.height || 100
        });

        // Scan reactions
        try {
          if (node.reactions && node.reactions.length > 0) {
            node.reactions.forEach(function(reaction, idx) {
              try {
                if (
                  reaction.action &&
                  reaction.action.type === 'NODE' &&
                  reaction.action.destinationId
                ) {
                  var destId = reaction.action.destinationId;
                  var connId = node.id + '__' + destId + '__' + idx;
                  var existing = getConnData(connId);
                  connections.push({
                    id: connId,
                    fromFrameId: node.id,
                    fromFrameName: node.name,
                    toFrameId: destId,
                    toFrameName: '',
                    tokenId: existing ? existing.tokenId : null
                  });
                }
              } catch(re) {}
            });
          }
        } catch(re) {}
      }

      if (node.children) {
        node.children.forEach(walkNode);
      }
    } catch(e) {}
  }

  try {
    figma.currentPage.children.forEach(walkNode);
  } catch(e) {
    console.error('scanFlowData error:', e);
  }

  // Fill toFrameName
  var frameMap = {};
  frames.forEach(function(f) { frameMap[f.id] = f.name; });
  connections.forEach(function(c) {
    c.toFrameName = frameMap[c.toFrameId] || 'Unknown';
  });

  return { frames: frames, connections: connections };
}

// ── Get layers from frame ─────────────────────────────────────
function getFrameLayers(frameId) {
  var layers = [];
  try {
    var node = figma.getNodeById(frameId);
    if (!node || !node.children) return layers;

    function collect(n, depth) {
      if (depth > 2) return;
      try {
        layers.push({
          id: n.id,
          name: n.name,
          type: n.type,
          hasChildren: !!(n.children && n.children.length > 0)
        });
        if (n.children && depth < 2) {
          n.children.forEach(function(child) { collect(child, depth + 1); });
        }
      } catch(e) {}
    }

    node.children.forEach(function(child) { collect(child, 0); });
  } catch(e) {
    console.error('getFrameLayers error:', e);
  }
  return layers;
}

// ── Apply token → Figma Prototype ────────────────────────────
function applyPrototypeTransition(connectionId, token) {
  try {
    var parts = connectionId.split('__');
    if (parts.length < 2) return;
    var fromFrameId = parts[0];
    var reactionIdx = parseInt(parts[2] || '0', 10);

    var node = figma.getNodeById(fromFrameId);
    if (!node || !node.reactions) return;

    var reactions = JSON.parse(JSON.stringify(node.reactions));
    var reaction = reactions[reactionIdx];
    if (!reaction || !reaction.action) return;

    var transition;
    if (token.bezier && token.durationMs) {
      transition = {
        type: 'SMART_ANIMATE',
        duration: token.durationMs / 1000,
        easing: {
          type: 'CUSTOM_CUBIC_BEZIER',
          easingFunctionCubicBezier: {
            x1: token.bezier[0], y1: token.bezier[1],
            x2: token.bezier[2], y2: token.bezier[3]
          }
        }
      };
    } else {
      transition = {
        type: 'SMART_ANIMATE',
        duration: 0.5,
        easing: { type: 'EASE_OUT' }
      };
    }

    reactions[reactionIdx] = Object.assign({}, reaction, {
      action: Object.assign({}, reaction.action, { transition: transition })
    });
    node.reactions = reactions;
  } catch(e) {
    console.error('applyPrototypeTransition error:', e);
  }
}

// ── Generate Motion Guide ─────────────────────────────────────
async function generateMotionGuide(frameId) {
  try {
    var frameNode = figma.getNodeById(frameId);
    if (!frameNode) { figma.notify('Frame not found.'); return; }

    var motionData = getFrameData(frameId);
    if (!motionData || !motionData.triggers || motionData.triggers.length === 0) {
      figma.notify('No motion data. Set triggers in Editor first.');
      return;
    }

    var tokens = getTokens();

    await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
    await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });

    var gf = figma.createFrame();
    gf.name = '🎬 Motion Guide — ' + frameNode.name;
    gf.x = frameNode.x + frameNode.width + 80;
    gf.y = frameNode.y;
    gf.layoutMode = 'VERTICAL';
    gf.primaryAxisSizingMode = 'AUTO';
    gf.counterAxisSizingMode = 'FIXED';
    gf.resize(580, 60);
    gf.paddingLeft = 20; gf.paddingRight = 20;
    gf.paddingTop = 20;  gf.paddingBottom = 20;
    gf.itemSpacing = 8;
    gf.cornerRadius = 8;
    gf.fills = [{ type: 'SOLID', color: { r: 0.10, g: 0.10, b: 0.12 } }];

    function txt(chars, r, g, b, size, bold) {
      var t = figma.createText();
      t.fontName = { family: 'Inter', style: bold ? 'Bold' : 'Regular' };
      t.fontSize = size || 10;
      t.characters = String(chars);
      t.fills = [{ type: 'SOLID', color: { r: r, g: g, b: b } }];
      t.resize(540, t.height);
      return t;
    }

    gf.appendChild(txt('Motion Guide — ' + frameNode.name, 0.95, 0.95, 0.95, 14, true));

    var div = figma.createRectangle();
    div.resize(540, 1);
    div.fills = [{ type: 'SOLID', color: { r: 0.25, g: 0.25, b: 0.28 } }];
    gf.appendChild(div);

    var icons = { tap:'👆 ', swipeUp:'↑ ', variableChange:'⚡ ', timer:'⏱ ', hover:'● ' };

    motionData.triggers.forEach(function(trigger) {
      var icon = icons[trigger.type] || '• ';
      gf.appendChild(txt(icon + 'Trigger: ' + (trigger.type || '').toUpperCase(), 0.85, 0.65, 0.20, 11, true));

      (trigger.layers || []).forEach(function(lm) {
        var token = tokens.find(function(t) { return t.id === lm.tokenId; });
        if (!token) return;
        try {
          var row = figma.createFrame();
          row.layoutMode = 'HORIZONTAL';
          row.primaryAxisSizingMode = 'FIXED';
          row.counterAxisSizingMode = 'AUTO';
          row.resize(540, 10);
          row.itemSpacing = 10;
          row.paddingLeft = 10; row.paddingRight = 10;
          row.paddingTop = 6;   row.paddingBottom = 6;
          row.cornerRadius = 4;
          row.fills = [{ type: 'SOLID', color: { r: 0.14, g: 0.14, b: 0.17 } }];

          function addCell(chars, r, g, b, w) {
            var t = figma.createText();
            t.fontName = { family: 'Inter', style: 'Regular' };
            t.fontSize = 10;
            t.characters = String(chars);
            t.fills = [{ type: 'SOLID', color: { r: r, g: g, b: b } }];
            t.resize(w, t.height);
            row.appendChild(t);
          }

          addCell(lm.layerName || '—',   0.75, 0.85, 1.00, 120);
          addCell(token.name,             0.55, 0.75, 1.00, 185);
          addCell(
            token.isSpring
              ? 'Spring k=' + (token.spring ? token.spring.stiffness : '?')
              : (lm.durationMs || token.durationMs || '?') + 'ms',
            0.20, 0.80, 0.70, 95
          );
          addCell('delay ' + (lm.delayMs || 0) + 'ms', 0.60, 0.60, 0.60, 80);

          gf.appendChild(row);
        } catch(e) {}
      });
    });

    figma.currentPage.selection = [gf];
    figma.viewport.scrollAndZoomIntoView([gf]);
    figma.notify('✨ Motion Guide generated!');
  } catch(e) {
    console.error('generateMotionGuide error:', e);
    figma.notify('Error generating guide: ' + String(e));
  }
}

// ── Message handler ───────────────────────────────────────────
figma.ui.onmessage = async function(msg) {
  if (!msg || !msg.type) return;

  try {
    if (msg.type === 'INIT') {
      var result = scanFlowData();
      var tokens = getTokens();
      var sel = figma.currentPage.selection[0];
      figma.ui.postMessage({
        type: 'INIT_DATA',
        frames: result.frames,
        connections: result.connections,
        tokens: tokens,
        selectedFrameId:   sel ? sel.id   : null,
        selectedFrameName: sel ? sel.name : null
      });

    } else if (msg.type === 'SCAN_FLOW') {
      var result = scanFlowData();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames: result.frames, connections: result.connections });

    } else if (msg.type === 'LOAD_FRAME') {
      var motionData = getFrameData(msg.frameId);
      var layers = getFrameLayers(msg.frameId);
      figma.ui.postMessage({ type: 'FRAME_DATA', frameId: msg.frameId, motionData: motionData, layers: layers });

    } else if (msg.type === 'SAVE_FRAME_DATA') {
      saveFrameData(msg.data);
      figma.notify('Saved.');
      var result = scanFlowData();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames: result.frames, connections: result.connections });

    } else if (msg.type === 'APPLY_CONNECTION_TOKEN') {
      var tokens = getTokens();
      var token = null;
      for (var i = 0; i < tokens.length; i++) {
        if (tokens[i].id === msg.tokenId) { token = tokens[i]; break; }
      }
      if (token) {
        var existing = getConnData(msg.connectionId) || { id: msg.connectionId, fromFrameId:'', fromFrameName:'', toFrameId:'', toFrameName:'', tokenId: null };
        existing.tokenId = msg.tokenId;
        saveConnData(existing);
        applyPrototypeTransition(msg.connectionId, token);
        figma.notify('Applied: ' + token.name);
      }

    } else if (msg.type === 'SAVE_TOKENS') {
      saveTokens(msg.tokens);
      figma.notify('Tokens saved.');

    } else if (msg.type === 'GENERATE_GUIDE') {
      await generateMotionGuide(msg.frameId);

    } else if (msg.type === 'SELECT_FRAME') {
      try {
        var node = figma.getNodeById(msg.frameId);
        if (node) {
          figma.currentPage.selection = [node];
          figma.viewport.scrollAndZoomIntoView([node]);
        }
      } catch(e) {}

    } else if (msg.type === 'SELECT_LAYER') {
      try {
        var node = figma.getNodeById(msg.layerId);
        if (node) figma.currentPage.selection = [node];
      } catch(e) {}

    } else if (msg.type === 'RESIZE') {
      try { figma.ui.resize(msg.width, msg.height); } catch(e) {}

    } else if (msg.type === 'EXPORT_TOKENS') {
      var tokens = getTokens();
      figma.ui.postMessage({ type: 'TOKENS_EXPORT', json: JSON.stringify(tokens, null, 2) });
    }

  } catch(e) {
    console.error('onmessage error [' + msg.type + ']:', e);
    figma.notify('Error: ' + String(e));
  }
};

// ── Event listeners ───────────────────────────────────────────
figma.on('selectionchange', function() {
  try {
    var sel = figma.currentPage.selection[0];
    if (sel && (sel.type === 'FRAME' || sel.type === 'COMPONENT')) {
      figma.ui.postMessage({ type: 'SELECTION_CHANGED', frameId: sel.id, frameName: sel.name });
    }
  } catch(e) {}
});

figma.on('documentchange', function(event) {
  try {
    if (event.documentChanges && event.documentChanges.length > 0) {
      figma.ui.postMessage({ type: 'DESIGN_CHANGED', count: event.documentChanges.length });
    }
  } catch(e) {}
});

// ── Launch ────────────────────────────────────────────────────
try {
  figma.showUI(__html__, { width: 960, height: 600 });
} catch(e) {
  console.error('showUI error:', e);
}

// Init tokens on first run
try {
  var existing = safeGetPluginData('mb_tokens');
  if (!existing) saveTokens(ST_TOKENS);
} catch(e) {}
