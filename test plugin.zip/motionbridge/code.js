// MotionBridge — Main Thread (code.js)
// Figma Plugin API: reads/writes to Figma file
// No TypeScript compilation needed — run directly

// ─────────────────────────────────────────
//  ST Motion Tokens (built-in presets)
// ─────────────────────────────────────────

const ST_TOKENS = [
  // Standard — interactive
  { id:'st-std-int-basic',    name:'st.standard.interactive.basic',     dna:'standard',   category:'interactive', variant:'basic',    easingName:'SineOut33',   bezier:[0.17,0.17,0.67,1], durationMs:100,  isSpring:false },
  { id:'st-std-int-smooth',   name:'st.standard.interactive.smooth',    dna:'standard',   category:'interactive', variant:'smooth',   easingName:'SineOut50',   bezier:[0.17,0.17,0.50,1], durationMs:200,  isSpring:false },
  { id:'st-std-int-emphasis', name:'st.standard.interactive.emphasis',  dna:'standard',   category:'interactive', variant:'emphasis', easingName:'SineOut70',   bezier:[0.17,0.17,0.30,1], durationMs:300,  isSpring:false },
  // Standard — transition
  { id:'st-std-tra-basic',    name:'st.standard.transition.basic',      dna:'standard',   category:'transition',  variant:'basic',    easingName:'SineInOut33', bezier:[0.33,0,0.67,1],    durationMs:250,  isSpring:false },
  { id:'st-std-tra-smooth',   name:'st.standard.transition.smooth',     dna:'standard',   category:'transition',  variant:'smooth',   easingName:'SineInOut50', bezier:[0.33,0,0.50,1],    durationMs:350,  isSpring:false },
  { id:'st-std-tra-emphasis', name:'st.standard.transition.emphasis',   dna:'standard',   category:'transition',  variant:'emphasis', easingName:'SineInOut70', bezier:[0.33,0,0.30,1],    durationMs:450,  isSpring:false },
  // Expressive — interactive
  { id:'st-exp-int-basic',    name:'st.expressive.interactive.basic',   dna:'expressive', category:'interactive', variant:'basic',    easingName:'Spring',      bezier:null,               durationMs:null, isSpring:true,  spring:{ stiffness:361, damping:1.0 } },
  { id:'st-exp-int-smooth',   name:'st.expressive.interactive.smooth',  dna:'expressive', category:'interactive', variant:'smooth',   easingName:'SineIn60',    bezier:[0.60,0,0.83,0.83], durationMs:300,  isSpring:false },
  { id:'st-exp-int-emphasis', name:'st.expressive.interactive.emphasis',dna:'expressive', category:'interactive', variant:'emphasis', easingName:'SineIn70',    bezier:[0.70,0,0.83,0.83], durationMs:400,  isSpring:false },
  // Expressive — transition
  { id:'st-exp-tra-basic',    name:'st.expressive.transition.basic',    dna:'expressive', category:'transition',  variant:'basic',    easingName:'SineIn50',    bezier:[0.50,0,0.83,0.83], durationMs:350,  isSpring:false },
  { id:'st-exp-tra-smooth',   name:'st.expressive.transition.smooth',   dna:'expressive', category:'transition',  variant:'smooth',   easingName:'SineInOut60', bezier:[0.33,0,0.40,1],    durationMs:450,  isSpring:false },
  { id:'st-exp-tra-emphasis', name:'st.expressive.transition.emphasis', dna:'expressive', category:'transition',  variant:'emphasis', easingName:'SineInOut80', bezier:[0.33,0,0.20,1],    durationMs:600,  isSpring:false },
  // Expressive — expressive
  { id:'st-exp-exp-basic',    name:'st.expressive.expressive.basic',    dna:'expressive', category:'expressive',  variant:'basic',    easingName:'SineOut80',   bezier:[0.17,0.17,0.20,1], durationMs:500,  isSpring:false },
  { id:'st-exp-exp-smooth',   name:'st.expressive.expressive.smooth',   dna:'expressive', category:'expressive',  variant:'smooth',   easingName:'SineIn80',    bezier:[0.80,0,0.83,0.83], durationMs:700,  isSpring:false },
  { id:'st-exp-exp-emphasis', name:'st.expressive.expressive.emphasis', dna:'expressive', category:'expressive',  variant:'emphasis', easingName:'SineInOut90', bezier:[0.33,0,0.10,1],    durationMs:900,  isSpring:false },
];

// ─────────────────────────────────────────
//  Plugin Data Keys
// ─────────────────────────────────────────

const KEY_TOKENS       = 'mb_tokens';
const KEY_FRAME_PREFIX = 'mb_frame_';
const KEY_CONN_PREFIX  = 'mb_conn_';
const NS               = 'motionbridge';

// ─────────────────────────────────────────
//  Storage Helpers
// ─────────────────────────────────────────

function getTokens() {
  try {
    const raw = figma.root.getSharedPluginData(NS, KEY_TOKENS);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return ST_TOKENS;
}

function saveTokens(tokens) {
  figma.root.setSharedPluginData(NS, KEY_TOKENS, JSON.stringify(tokens));
}

function getFrameData(frameId) {
  try {
    const raw = figma.root.getSharedPluginData(NS, KEY_FRAME_PREFIX + frameId);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return null;
}

function saveFrameData(data) {
  figma.root.setSharedPluginData(NS, KEY_FRAME_PREFIX + data.frameId, JSON.stringify(data));
}

function getConnectionData(connId) {
  try {
    const raw = figma.root.getSharedPluginData(NS, KEY_CONN_PREFIX + connId);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return null;
}

function saveConnectionData(data) {
  figma.root.setSharedPluginData(NS, KEY_CONN_PREFIX + data.id, JSON.stringify(data));
}

// ─────────────────────────────────────────
//  Scan Figma file — Frames + Connections
// ─────────────────────────────────────────

function scanFlowData() {
  const frames = [];
  const connections = [];

  function walkNode(node) {
    if (node.type === 'FRAME' || node.type === 'COMPONENT') {
      const bbox = node.absoluteBoundingBox;
      const motionData = getFrameData(node.id);
      const motionCount = motionData
        ? motionData.triggers.reduce((acc, t) => acc + t.layers.length, 0)
        : 0;

      frames.push({
        id:          node.id,
        name:        node.name,
        motionCount,
        x:           bbox ? bbox.x : 0,
        y:           bbox ? bbox.y : 0,
        width:       node.width,
        height:      node.height,
      });

      // Scan prototype reactions
      if (node.reactions && node.reactions.length > 0) {
        node.reactions.forEach((reaction, idx) => {
          if (
            reaction.action &&
            reaction.action.type === 'NODE' &&
            reaction.action.destinationId
          ) {
            const destId  = reaction.action.destinationId;
            const connId  = `${node.id}_${destId}_${idx}`;
            const existing = getConnectionData(connId);

            connections.push({
              id:            connId,
              fromFrameId:   node.id,
              fromFrameName: node.name,
              toFrameId:     destId,
              toFrameName:   '',       // filled after
              tokenId:       existing ? existing.tokenId : null,
              transitionType: reaction.action.transition
                ? reaction.action.transition.type
                : 'INSTANT',
            });
          }
        });
      }
    }

    if (node.children) {
      node.children.forEach(walkNode);
    }
  }

  figma.currentPage.children.forEach(walkNode);

  // Fill toFrameName
  const frameMap = new Map(frames.map(f => [f.id, f.name]));
  connections.forEach(c => {
    c.toFrameName = frameMap.get(c.toFrameId) || 'Unknown';
  });

  return { frames, connections };
}

// ─────────────────────────────────────────
//  Get layers from a Frame node
// ─────────────────────────────────────────

function getFrameLayers(frameId) {
  const node = figma.getNodeById(frameId);
  if (!node || !node.children) return [];

  const layers = [];

  function collect(n, depth) {
    if (depth > 3) return;
    layers.push({
      id:          n.id,
      name:        n.name,
      type:        n.type,
      hasChildren: !!(n.children && n.children.length > 0),
    });
    if (n.children && depth < 2) {
      n.children.forEach(child => collect(child, depth + 1));
    }
  }

  node.children.forEach(child => collect(child, 0));
  return layers;
}

// ─────────────────────────────────────────
//  Apply Token → Figma Prototype transition
// ─────────────────────────────────────────

function applyPrototypeTransition(connectionId, token) {
  const parts = connectionId.split('_');
  if (parts.length < 2) return;

  const fromFrameId  = parts[0];
  const reactionIdx  = parseInt(parts[2] || '0', 10);

  const node = figma.getNodeById(fromFrameId);
  if (!node || !node.reactions) return;

  const reactions = node.reactions.slice(); // clone

  if (!reactions[reactionIdx]) return;

  let transition = null;

  if (token.isSpring && token.spring) {
    // Figma currently supports SMART_ANIMATE with custom bezier best;
    // approximate spring with a fast-out curve
    transition = {
      type:     'SMART_ANIMATE',
      duration: 0.4,
      easing: {
        type: 'CUSTOM_CUBIC_BEZIER',
        easingFunctionCubicBezier: { x1:0.2, y1:0, x2:0, y2:1 },
      },
    };
  } else if (token.bezier && token.durationMs) {
    transition = {
      type:     'SMART_ANIMATE',
      duration: token.durationMs / 1000,
      easing: {
        type: 'CUSTOM_CUBIC_BEZIER',
        easingFunctionCubicBezier: {
          x1: token.bezier[0],
          y1: token.bezier[1],
          x2: token.bezier[2],
          y2: token.bezier[3],
        },
      },
    };
  }

  if (!transition) return;

  try {
    const updated = Object.assign({}, reactions[reactionIdx]);
    updated.action = Object.assign({}, updated.action, { transition });
    reactions[reactionIdx] = updated;
    node.reactions = reactions;
  } catch (e) {
    console.error('applyPrototypeTransition failed:', e);
  }
}

// ─────────────────────────────────────────
//  Generate Motion Guide on Canvas
// ─────────────────────────────────────────

async function generateMotionGuide(frameId) {
  const frameNode = figma.getNodeById(frameId);
  if (!frameNode) { figma.notify('Frame not found.'); return; }

  const motionData = getFrameData(frameId);
  if (!motionData || !motionData.triggers || motionData.triggers.length === 0) {
    figma.notify('No motion data found for this frame. Set up motions in the Editor tab first.');
    return;
  }

  const tokens = getTokens();

  await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
  await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });

  // ── Guide frame container ──
  const guideFrame = figma.createFrame();
  guideFrame.name        = `🎬 Motion Guide — ${frameNode.name}`;
  guideFrame.x           = frameNode.x + frameNode.width + 80;
  guideFrame.y           = frameNode.y;
  guideFrame.layoutMode  = 'VERTICAL';
  guideFrame.primaryAxisSizingMode   = 'AUTO';
  guideFrame.counterAxisSizingMode   = 'FIXED';
  guideFrame.resize(620, 100);
  guideFrame.paddingLeft   = 20;
  guideFrame.paddingRight  = 20;
  guideFrame.paddingTop    = 20;
  guideFrame.paddingBottom = 20;
  guideFrame.itemSpacing   = 10;
  guideFrame.cornerRadius  = 8;
  guideFrame.fills = [{ type:'SOLID', color:{ r:0.08, g:0.08, b:0.10 } }];

  // ── Title ──
  const titleTxt = figma.createText();
  titleTxt.fontName  = { family:'Inter', style:'Bold' };
  titleTxt.fontSize  = 14;
  titleTxt.characters = `Motion Guide — ${frameNode.name}`;
  titleTxt.fills     = [{ type:'SOLID', color:{ r:0.95, g:0.95, b:0.95 } }];
  titleTxt.resize(580, titleTxt.height);
  guideFrame.appendChild(titleTxt);

  // ── Divider ──
  const div = figma.createRectangle();
  div.resize(580, 1);
  div.fills = [{ type:'SOLID', color:{ r:0.22, g:0.22, b:0.25 } }];
  guideFrame.appendChild(div);

  // ── Each trigger ──
  for (const trigger of motionData.triggers) {
    if (!trigger.layers || trigger.layers.length === 0) continue;

    // Trigger label
    const trigIcons = { tap:'👆', swipeUp:'↑', swipeDown:'↓', variableChange:'⚡', timer:'⏱', hover:'●' };
    const trigLabel = figma.createText();
    trigLabel.fontName   = { family:'Inter', style:'Bold' };
    trigLabel.fontSize   = 11;
    trigLabel.characters = `${trigIcons[trigger.type] || '•'}  Trigger: ${trigger.type.toUpperCase()}`;
    trigLabel.fills      = [{ type:'SOLID', color:{ r:0.85, g:0.65, b:0.18 } }];
    trigLabel.resize(580, trigLabel.height);
    guideFrame.appendChild(trigLabel);

    // ── Each layer motion ──
    for (const layerMotion of trigger.layers) {
      const token = tokens.find(t => t.id === layerMotion.tokenId);
      if (!token) continue;

      const rowFrame = figma.createFrame();
      rowFrame.layoutMode  = 'HORIZONTAL';
      rowFrame.primaryAxisSizingMode   = 'FIXED';
      rowFrame.counterAxisSizingMode   = 'AUTO';
      rowFrame.resize(580, 10);
      rowFrame.itemSpacing  = 10;
      rowFrame.paddingLeft  = 12;
      rowFrame.paddingRight = 12;
      rowFrame.paddingTop   = 8;
      rowFrame.paddingBottom = 8;
      rowFrame.cornerRadius = 4;
      rowFrame.fills = [{ type:'SOLID', color:{ r:0.12, g:0.12, b:0.15 } }];
      rowFrame.counterAxisAlignItems = 'CENTER';

      // Layer name
      function makeText(chars, size, color, w) {
        const t = figma.createText();
        t.fontName   = { family:'Inter', style:'Regular' };
        t.fontSize   = size;
        t.characters = chars;
        t.fills      = [{ type:'SOLID', color }];
        t.resize(w, t.height);
        t.textTruncation = 'ENDING';
        return t;
      }

      rowFrame.appendChild(makeText(
        layerMotion.layerName, 11,
        { r:0.72, g:0.84, b:1.0 }, 130
      ));
      rowFrame.appendChild(makeText(
        token.name, 9,
        { r:0.40, g:0.60, b:1.0 }, 200
      ));
      rowFrame.appendChild(makeText(
        token.isSpring
          ? `Spring  k=${token.spring.stiffness}  d=${token.spring.damping}`
          : `${layerMotion.durationMs}ms`,
        10, { r:0.18, g:0.76, b:0.68 }, 110
      ));
      rowFrame.appendChild(makeText(
        `delay ${layerMotion.delayMs}ms`, 10,
        { r:0.55, g:0.55, b:0.58 }, 80
      ));
      rowFrame.appendChild(makeText(
        (layerMotion.properties || []).join(', '), 9,
        { r:0.45, g:0.45, b:0.50 }, 90
      ));

      guideFrame.appendChild(rowFrame);
    }
  }

  // ── Bezier values footer ──
  const footerDiv = figma.createRectangle();
  footerDiv.resize(580, 1);
  footerDiv.fills = [{ type:'SOLID', color:{ r:0.22, g:0.22, b:0.25 } }];
  guideFrame.appendChild(footerDiv);

  const footerTxt = figma.createText();
  footerTxt.fontName   = { family:'Inter', style:'Regular' };
  footerTxt.fontSize   = 9;
  footerTxt.characters = 'Generated by MotionBridge · SmartThings Motion Token System v1.0';
  footerTxt.fills      = [{ type:'SOLID', color:{ r:0.40, g:0.40, b:0.45 } }];
  footerTxt.resize(580, footerTxt.height);
  guideFrame.appendChild(footerTxt);

  figma.currentPage.selection = [guideFrame];
  figma.viewport.scrollAndZoomIntoView([guideFrame]);
  figma.notify('✨ Motion Guide generated on canvas!');
}

// ─────────────────────────────────────────
//  Message Handler
// ─────────────────────────────────────────

figma.ui.onmessage = async (msg) => {
  switch (msg.type) {

    // ── Init ──
    case 'INIT': {
      const { frames, connections } = scanFlowData();
      const tokens = getTokens();
      const sel = figma.currentPage.selection[0];
      figma.ui.postMessage({
        type:              'INIT_DATA',
        frames,
        connections,
        tokens,
        selectedFrameId:   sel ? sel.id   : null,
        selectedFrameName: sel ? sel.name : null,
      });
      break;
    }

    // ── Rescan flow ──
    case 'SCAN_FLOW': {
      const { frames, connections } = scanFlowData();
      figma.ui.postMessage({ type:'FLOW_DATA', frames, connections });
      break;
    }

    // ── Load frame ──
    case 'LOAD_FRAME': {
      const motionData = getFrameData(msg.frameId);
      const layers     = getFrameLayers(msg.frameId);
      figma.ui.postMessage({ type:'FRAME_DATA', frameId:msg.frameId, motionData, layers });
      break;
    }

    // ── Save frame data ──
    case 'SAVE_FRAME_DATA': {
      saveFrameData(msg.data);
      figma.notify('Motion data saved.');
      const { frames, connections } = scanFlowData();
      figma.ui.postMessage({ type:'FLOW_DATA', frames, connections });
      break;
    }

    // ── Apply token to prototype connection ──
    case 'APPLY_CONNECTION_TOKEN': {
      const { connectionId, tokenId } = msg;
      const tokens = getTokens();
      const token  = tokens.find(t => t.id === tokenId);
      if (!token) break;

      const existing = getConnectionData(connectionId) || {
        id:             connectionId,
        fromFrameId:    connectionId.split('_')[0],
        fromFrameName:  '',
        toFrameId:      connectionId.split('_')[1],
        toFrameName:    '',
        tokenId:        null,
        transitionType: 'SMART_ANIMATE',
      };
      existing.tokenId = tokenId;
      saveConnectionData(existing);
      applyPrototypeTransition(connectionId, token);
      figma.notify(`✓ Token applied: ${token.name}`);
      break;
    }

    // ── Save tokens ──
    case 'SAVE_TOKENS': {
      saveTokens(msg.tokens);
      figma.notify('Tokens saved to team library.');
      break;
    }

    // ── Generate Motion Guide ──
    case 'GENERATE_GUIDE': {
      await generateMotionGuide(msg.frameId);
      break;
    }

    // ── Select frame in canvas ──
    case 'SELECT_FRAME': {
      const node = figma.getNodeById(msg.frameId);
      if (node) {
        figma.currentPage.selection = [node];
        figma.viewport.scrollAndZoomIntoView([node]);
      }
      break;
    }

    // ── Select layer ──
    case 'SELECT_LAYER': {
      const node = figma.getNodeById(msg.layerId);
      if (node) figma.currentPage.selection = [node];
      break;
    }

    // ── Resize window ──
    case 'RESIZE': {
      figma.ui.resize(msg.width, msg.height);
      break;
    }

    // ── Export tokens as JSON ──
    case 'EXPORT_TOKENS': {
      const tokens = getTokens();
      figma.ui.postMessage({
        type: 'TOKENS_EXPORT',
        json: JSON.stringify(tokens, null, 2),
      });
      break;
    }
  }
};

// ─────────────────────────────────────────
//  Selection change listener
// ─────────────────────────────────────────

figma.on('selectionchange', () => {
  const sel = figma.currentPage.selection[0];
  if (sel && (sel.type === 'FRAME' || sel.type === 'COMPONENT')) {
    figma.ui.postMessage({
      type:      'SELECTION_CHANGED',
      frameId:   sel.id,
      frameName: sel.name,
    });
  }
});

// ─────────────────────────────────────────
//  Document change listener (design update detection)
// ─────────────────────────────────────────

figma.on('documentchange', (event) => {
  const relevant = event.documentChanges.filter(
    c => c.type === 'CREATE' || c.type === 'DELETE' || c.type === 'PROPERTY_CHANGE'
  );
  if (relevant.length > 0) {
    figma.ui.postMessage({ type:'DESIGN_CHANGED', count: relevant.length });
  }
});

// ─────────────────────────────────────────
//  Init
// ─────────────────────────────────────────

figma.showUI(__html__, { width:960, height:600, title:'MotionBridge' });

// First-time token setup
const existingTokens = figma.root.getSharedPluginData(NS, KEY_TOKENS);
if (!existingTokens) {
  saveTokens(ST_TOKENS);
}
