// MotionBridge — Main Thread (code.ts)
// Figma Plugin API: reads/writes to Figma file
// Communicates with UI via postMessage

// ─────────────────────────────────────────
//  Types
// ─────────────────────────────────────────

interface MotionToken {
  id: string;
  name: string;          // st.expressive.transition.emphasis
  dna: 'standard' | 'expressive';
  category: 'interactive' | 'transition' | 'expressive';
  variant: 'basic' | 'smooth' | 'emphasis';
  easingName: string;    // SineInOut80
  bezier: [number, number, number, number] | null;
  durationMs: number | null;  // null = Spring
  isSpring: boolean;
  spring?: { stiffness: number; damping: number };
}

interface LayerMotion {
  layerId: string;
  layerName: string;
  tokenId: string;
  durationMs: number;
  delayMs: number;
  properties: string[];  // ['opacity', 'translateY', 'scale']
}

interface TriggerRule {
  id: string;
  type: 'tap' | 'swipeUp' | 'swipeDown' | 'variableChange' | 'timer' | 'hover';
  variableName?: string;
  timerMs?: number;
  layers: LayerMotion[];
  condition?: {
    variable: string;
    operator: '==' | '!=' | '>' | '<' | '>=' | '<=';
    value: string;
    action: 'changeVariant' | 'applyToken' | 'setVariable';
    actionValue: string;
  };
}

interface FrameMotionData {
  frameId: string;
  frameName: string;
  triggers: TriggerRule[];
}

interface ConnectionData {
  id: string;
  fromFrameId: string;
  fromFrameName: string;
  toFrameId: string;
  toFrameName: string;
  tokenId: string | null;
  transitionType: string;
}

// ─────────────────────────────────────────
//  ST Motion Tokens (built-in presets)
// ─────────────────────────────────────────

const ST_TOKENS: MotionToken[] = [
  // Standard — interactive
  { id: 'st-std-int-basic',    name: 'st.standard.interactive.basic',    dna: 'standard',    category: 'interactive', variant: 'basic',    easingName: 'SineOut33',   bezier: [0.17, 0.17, 0.67, 1], durationMs: 100,  isSpring: false },
  { id: 'st-std-int-smooth',   name: 'st.standard.interactive.smooth',   dna: 'standard',    category: 'interactive', variant: 'smooth',   easingName: 'SineOut50',   bezier: [0.17, 0.17, 0.50, 1], durationMs: 200,  isSpring: false },
  { id: 'st-std-int-emphasis', name: 'st.standard.interactive.emphasis', dna: 'standard',    category: 'interactive', variant: 'emphasis', easingName: 'SineOut70',   bezier: [0.17, 0.17, 0.30, 1], durationMs: 300,  isSpring: false },
  // Standard — transition
  { id: 'st-std-tra-basic',    name: 'st.standard.transition.basic',     dna: 'standard',    category: 'transition',  variant: 'basic',    easingName: 'SineInOut33', bezier: [0.33, 0, 0.67, 1],    durationMs: 250,  isSpring: false },
  { id: 'st-std-tra-smooth',   name: 'st.standard.transition.smooth',    dna: 'standard',    category: 'transition',  variant: 'smooth',   easingName: 'SineInOut50', bezier: [0.33, 0, 0.50, 1],    durationMs: 350,  isSpring: false },
  { id: 'st-std-tra-emphasis', name: 'st.standard.transition.emphasis',  dna: 'standard',    category: 'transition',  variant: 'emphasis', easingName: 'SineInOut70', bezier: [0.33, 0, 0.30, 1],    durationMs: 450,  isSpring: false },
  // Expressive — interactive
  { id: 'st-exp-int-basic',    name: 'st.expressive.interactive.basic',  dna: 'expressive',  category: 'interactive', variant: 'basic',    easingName: 'Spring',      bezier: null,                  durationMs: null, isSpring: true,  spring: { stiffness: 361, damping: 1.0 } },
  { id: 'st-exp-int-smooth',   name: 'st.expressive.interactive.smooth', dna: 'expressive',  category: 'interactive', variant: 'smooth',   easingName: 'SineIn60',    bezier: [0.60, 0, 0.83, 0.83], durationMs: 300,  isSpring: false },
  { id: 'st-exp-int-emphasis', name: 'st.expressive.interactive.emphasis',dna: 'expressive', category: 'interactive', variant: 'emphasis', easingName: 'SineIn70',    bezier: [0.70, 0, 0.83, 0.83], durationMs: 400,  isSpring: false },
  // Expressive — transition
  { id: 'st-exp-tra-basic',    name: 'st.expressive.transition.basic',   dna: 'expressive',  category: 'transition',  variant: 'basic',    easingName: 'SineIn50',    bezier: [0.50, 0, 0.83, 0.83], durationMs: 350,  isSpring: false },
  { id: 'st-exp-tra-smooth',   name: 'st.expressive.transition.smooth',  dna: 'expressive',  category: 'transition',  variant: 'smooth',   easingName: 'SineInOut60', bezier: [0.33, 0, 0.40, 1],    durationMs: 450,  isSpring: false },
  { id: 'st-exp-tra-emphasis', name: 'st.expressive.transition.emphasis',dna: 'expressive',  category: 'transition',  variant: 'emphasis', easingName: 'SineInOut80', bezier: [0.33, 0, 0.20, 1],    durationMs: 600,  isSpring: false },
  // Expressive — expressive
  { id: 'st-exp-exp-basic',    name: 'st.expressive.expressive.basic',   dna: 'expressive',  category: 'expressive',  variant: 'basic',    easingName: 'SineOut80',   bezier: [0.17, 0.17, 0.20, 1], durationMs: 500,  isSpring: false },
  { id: 'st-exp-exp-smooth',   name: 'st.expressive.expressive.smooth',  dna: 'expressive',  category: 'expressive',  variant: 'smooth',   easingName: 'SineIn80',    bezier: [0.80, 0, 0.83, 0.83], durationMs: 700,  isSpring: false },
  { id: 'st-exp-exp-emphasis', name: 'st.expressive.expressive.emphasis',dna: 'expressive',  category: 'expressive',  variant: 'emphasis', easingName: 'SineInOut90', bezier: [0.33, 0, 0.10, 1],    durationMs: 900,  isSpring: false },
];

// ─────────────────────────────────────────
//  Plugin Data Keys
// ─────────────────────────────────────────

const KEY_TOKENS       = 'mb_tokens';
const KEY_FRAME_PREFIX = 'mb_frame_';
const KEY_CONN_PREFIX  = 'mb_conn_';

// ─────────────────────────────────────────
//  Helpers
// ─────────────────────────────────────────

function getTokens(): MotionToken[] {
  try {
    const raw = figma.root.getSharedPluginData('motionbridge', KEY_TOKENS);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return ST_TOKENS; // fallback to built-in
}

function saveTokens(tokens: MotionToken[]): void {
  figma.root.setSharedPluginData('motionbridge', KEY_TOKENS, JSON.stringify(tokens));
}

function getFrameData(frameId: string): FrameMotionData | null {
  try {
    const raw = figma.root.getSharedPluginData('motionbridge', KEY_FRAME_PREFIX + frameId);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return null;
}

function saveFrameData(data: FrameMotionData): void {
  figma.root.setSharedPluginData('motionbridge', KEY_FRAME_PREFIX + data.frameId, JSON.stringify(data));
}

function getConnectionData(connId: string): ConnectionData | null {
  try {
    const raw = figma.root.getSharedPluginData('motionbridge', KEY_CONN_PREFIX + connId);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return null;
}

function saveConnectionData(data: ConnectionData): void {
  figma.root.setSharedPluginData('motionbridge', KEY_CONN_PREFIX + data.id, JSON.stringify(data));
}

// ─────────────────────────────────────────
//  Scan Figma file for Frames + Connections
// ─────────────────────────────────────────

function scanFlowData() {
  const frames: { id: string; name: string; motionCount: number; x: number; y: number; width: number; height: number }[] = [];
  const connections: ConnectionData[] = [];

  function walkNode(node: BaseNode) {
    if (node.type === 'FRAME' || node.type === 'COMPONENT') {
      const frameNode = node as FrameNode;

      // Get position for flow map layout
      const absX = 'absoluteBoundingBox' in frameNode && frameNode.absoluteBoundingBox ? frameNode.absoluteBoundingBox.x : 0;
      const absY = 'absoluteBoundingBox' in frameNode && frameNode.absoluteBoundingBox ? frameNode.absoluteBoundingBox.y : 0;

      const motionData = getFrameData(node.id);
      const motionCount = motionData ? motionData.triggers.reduce((acc, t) => acc + t.layers.length, 0) : 0;

      frames.push({
        id: node.id,
        name: node.name,
        motionCount,
        x: absX,
        y: absY,
        width: frameNode.width,
        height: frameNode.height,
      });

      // Scan prototype interactions (connections to other frames)
      if ('reactions' in frameNode && frameNode.reactions) {
        frameNode.reactions.forEach((reaction, idx) => {
          if (reaction.action && reaction.action.type === 'NODE' && reaction.action.destinationId) {
            const destId = reaction.action.destinationId;
            const connId = `${node.id}_${destId}_${idx}`;
            const existing = getConnectionData(connId);

            connections.push({
              id: connId,
              fromFrameId: node.id,
              fromFrameName: node.name,
              toFrameId: destId,
              toFrameName: '', // filled below
              tokenId: existing?.tokenId ?? null,
              transitionType: reaction.action.transition?.type ?? 'INSTANT',
            });
          }
        });
      }
    }

    if ('children' in node) {
      (node as ChildrenMixin).children.forEach(walkNode);
    }
  }

  figma.currentPage.children.forEach(walkNode);

  // Fill toFrameName
  const frameMap = new Map(frames.map(f => [f.id, f.name]));
  connections.forEach(c => {
    c.toFrameName = frameMap.get(c.toFrameId) ?? 'Unknown';
  });

  return { frames, connections };
}

// ─────────────────────────────────────────
//  Get layers from selected frame
// ─────────────────────────────────────────

function getFrameLayers(frameId: string) {
  const node = figma.getNodeById(frameId);
  if (!node || !('children' in node)) return [];

  const layers: { id: string; name: string; type: string; hasChildren: boolean }[] = [];

  function collect(n: BaseNode, depth = 0) {
    if (depth > 3) return; // max depth
    const layer = {
      id: n.id,
      name: n.name,
      type: n.type,
      hasChildren: 'children' in n && (n as ChildrenMixin).children.length > 0,
    };
    layers.push(layer);
    if ('children' in n && depth < 2) {
      (n as ChildrenMixin).children.forEach(child => collect(child, depth + 1));
    }
  }

  (node as ChildrenMixin).children.forEach(child => collect(child));
  return layers;
}

// ─────────────────────────────────────────
//  Apply motion to Figma Prototype
// ─────────────────────────────────────────

function applyPrototypeTransition(connectionId: string, token: MotionToken) {
  // Parse connection ID to get fromFrameId and find the reaction
  const parts = connectionId.split('_');
  if (parts.length < 2) return;

  const fromFrameId = parts[0];
  const toFrameId = parts[1];
  const reactionIdx = parseInt(parts[2] ?? '0', 10);

  const node = figma.getNodeById(fromFrameId);
  if (!node || !('reactions' in node)) return;

  const frameNode = node as FrameNode;
  const reactions = [...frameNode.reactions];

  if (!reactions[reactionIdx]) return;

  // Build transition based on token
  let transition: Transition | null = null;

  if (token.isSpring && token.spring) {
    // Spring transition
    transition = {
      type: 'SPRING',
      duration: 0.5, // Figma API spring duration hint
      easing: { type: 'SPRING', stiffness: token.spring.stiffness, damping: token.spring.damping },
    } as any;
  } else if (token.bezier && token.durationMs) {
    transition = {
      type: 'SMART_ANIMATE',
      duration: token.durationMs / 1000,
      easing: {
        type: 'CUSTOM_CUBIC_BEZIER',
        easingFunctionCubicBezier: {
          x1: token.bezier[0],
          y1: token.bezier[1],
          x2: token.bezier[2],
          y2: token.bezier[3],
        },
      },
    } as any;
  }

  if (!transition) return;

  try {
    reactions[reactionIdx] = {
      ...reactions[reactionIdx],
      action: {
        ...reactions[reactionIdx].action,
        transition,
      } as any,
    };
    frameNode.reactions = reactions;
  } catch (e) {
    console.error('Failed to apply transition:', e);
  }
}

// ─────────────────────────────────────────
//  Generate Motion Guide on Canvas
// ─────────────────────────────────────────

async function generateMotionGuide(frameId: string) {
  const frameNode = figma.getNodeById(frameId) as FrameNode;
  if (!frameNode) return;

  const motionData = getFrameData(frameId);
  if (!motionData || motionData.triggers.length === 0) {
    figma.notify('No motion data found for this frame.');
    return;
  }

  const tokens = getTokens();

  // Load font first
  await figma.loadFontAsync({ family: 'Inter', style: 'Regular' });
  await figma.loadFontAsync({ family: 'Inter', style: 'Bold' });

  // Create guide frame
  const guideFrame = figma.createFrame();
  guideFrame.name = `🎬 Motion Guide — ${frameNode.name}`;
  guideFrame.resize(600, 40); // will grow
  guideFrame.x = frameNode.x + frameNode.width + 80;
  guideFrame.y = frameNode.y;
  guideFrame.fills = [{ type: 'SOLID', color: { r: 0.1, g: 0.1, b: 0.12 }, opacity: 1 }];
  guideFrame.cornerRadius = 8;
  guideFrame.paddingLeft = 20;
  guideFrame.paddingRight = 20;
  guideFrame.paddingTop = 20;
  guideFrame.paddingBottom = 20;
  guideFrame.itemSpacing = 12;
  guideFrame.layoutMode = 'VERTICAL';
  guideFrame.primaryAxisSizingMode = 'AUTO';
  guideFrame.counterAxisSizingMode = 'FIXED';

  // Title
  const titleText = figma.createText();
  titleText.fontName = { family: 'Inter', style: 'Bold' };
  titleText.fontSize = 14;
  titleText.characters = `Motion Guide — ${frameNode.name}`;
  titleText.fills = [{ type: 'SOLID', color: { r: 0.95, g: 0.95, b: 0.95 } }];
  titleText.resize(560, titleText.height);
  guideFrame.appendChild(titleText);

  // Divider
  const divider = figma.createRectangle();
  divider.resize(560, 1);
  divider.fills = [{ type: 'SOLID', color: { r: 0.25, g: 0.25, b: 0.28 } }];
  guideFrame.appendChild(divider);

  // Each trigger
  for (const trigger of motionData.triggers) {
    // Trigger label
    const triggerLabel = figma.createText();
    triggerLabel.fontName = { family: 'Inter', style: 'Bold' };
    triggerLabel.fontSize = 11;
    const triggerIcon = { tap: '👆', swipeUp: '↑', variableChange: '⚡', timer: '⏱', hover: '●' }[trigger.type] ?? '•';
    triggerLabel.characters = `${triggerIcon} Trigger: ${trigger.type.toUpperCase()}`;
    triggerLabel.fills = [{ type: 'SOLID', color: { r: 0.85, g: 0.65, b: 0.2 } }];
    triggerLabel.resize(560, triggerLabel.height);
    guideFrame.appendChild(triggerLabel);

    // Each layer motion
    for (const layerMotion of trigger.layers) {
      const token = tokens.find(t => t.id === layerMotion.tokenId);
      if (!token) continue;

      const rowFrame = figma.createFrame();
      rowFrame.layoutMode = 'HORIZONTAL';
      rowFrame.primaryAxisSizingMode = 'FIXED';
      rowFrame.counterAxisSizingMode = 'AUTO';
      rowFrame.resize(560, 10);
      rowFrame.itemSpacing = 12;
      rowFrame.paddingLeft = 12;
      rowFrame.paddingRight = 12;
      rowFrame.paddingTop = 8;
      rowFrame.paddingBottom = 8;
      rowFrame.fills = [{ type: 'SOLID', color: { r: 0.14, g: 0.14, b: 0.17 } }];
      rowFrame.cornerRadius = 4;

      // Layer name
      const layerNameText = figma.createText();
      layerNameText.fontName = { family: 'Inter', style: 'Bold' };
      layerNameText.fontSize = 10;
      layerNameText.characters = layerMotion.layerName;
      layerNameText.fills = [{ type: 'SOLID', color: { r: 0.75, g: 0.85, b: 1.0 } }];
      layerNameText.resize(120, layerNameText.height);
      rowFrame.appendChild(layerNameText);

      // Token name
      const tokenText = figma.createText();
      tokenText.fontName = { family: 'Inter', style: 'Regular' };
      tokenText.fontSize = 9;
      tokenText.characters = token.name;
      tokenText.fills = [{ type: 'SOLID', color: { r: 0.55, g: 0.75, b: 1.0 } }];
      tokenText.resize(200, tokenText.height);
      rowFrame.appendChild(tokenText);

      // Duration
      const durText = figma.createText();
      durText.fontName = { family: 'Inter', style: 'Regular' };
      durText.fontSize = 10;
      durText.characters = token.isSpring
        ? `Spring k=${token.spring?.stiffness} d=${token.spring?.damping}`
        : `${layerMotion.durationMs}ms`;
      durText.fills = [{ type: 'SOLID', color: { r: 0.2, g: 0.8, b: 0.7 } }];
      durText.resize(100, durText.height);
      rowFrame.appendChild(durText);

      // Delay
      const delayText = figma.createText();
      delayText.fontName = { family: 'Inter', style: 'Regular' };
      delayText.fontSize = 10;
      delayText.characters = `delay ${layerMotion.delayMs}ms`;
      delayText.fills = [{ type: 'SOLID', color: { r: 0.6, g: 0.6, b: 0.6 } }];
      delayText.resize(80, delayText.height);
      rowFrame.appendChild(delayText);

      // Properties
      const propsText = figma.createText();
      propsText.fontName = { family: 'Inter', style: 'Regular' };
      propsText.fontSize = 9;
      propsText.characters = layerMotion.properties.join(', ');
      propsText.fills = [{ type: 'SOLID', color: { r: 0.5, g: 0.5, b: 0.55 } }];
      propsText.resize(100, propsText.height);
      rowFrame.appendChild(propsText);

      guideFrame.appendChild(rowFrame);
    }
  }

  // Select and zoom
  figma.currentPage.selection = [guideFrame];
  figma.viewport.scrollAndZoomIntoView([guideFrame]);
  figma.notify('✨ Motion Guide generated!');
}

// ─────────────────────────────────────────
//  Message Handler
// ─────────────────────────────────────────

figma.ui.onmessage = async (msg: { type: string; [key: string]: any }) => {

  switch (msg.type) {

    // ── Init: send all data to UI ──
    case 'INIT': {
      const { frames, connections } = scanFlowData();
      const tokens = getTokens();
      const selectedFrame = figma.currentPage.selection[0];

      figma.ui.postMessage({
        type: 'INIT_DATA',
        frames,
        connections,
        tokens,
        selectedFrameId: selectedFrame?.id ?? null,
        selectedFrameName: selectedFrame?.name ?? null,
      });
      break;
    }

    // ── Rescan flow ──
    case 'SCAN_FLOW': {
      const { frames, connections } = scanFlowData();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames, connections });
      break;
    }

    // ── Load frame data ──
    case 'LOAD_FRAME': {
      const { frameId } = msg;
      const motionData = getFrameData(frameId);
      const layers = getFrameLayers(frameId);
      figma.ui.postMessage({ type: 'FRAME_DATA', frameId, motionData, layers });
      break;
    }

    // ── Save frame data ──
    case 'SAVE_FRAME_DATA': {
      saveFrameData(msg.data as FrameMotionData);
      figma.notify('Motion data saved.');
      // Rescan to update flow
      const { frames, connections } = scanFlowData();
      figma.ui.postMessage({ type: 'FLOW_DATA', frames, connections });
      break;
    }

    // ── Apply token to connection ──
    case 'APPLY_CONNECTION_TOKEN': {
      const { connectionId, tokenId } = msg;
      const tokens = getTokens();
      const token = tokens.find(t => t.id === tokenId);
      if (!token) break;

      // Save to plugin data
      const existing = getConnectionData(connectionId) ?? {
        id: connectionId,
        fromFrameId: '',
        fromFrameName: '',
        toFrameId: '',
        toFrameName: '',
        tokenId: null,
        transitionType: 'SMART_ANIMATE',
      };
      existing.tokenId = tokenId;
      saveConnectionData(existing);

      // Apply to Figma prototype
      applyPrototypeTransition(connectionId, token);

      figma.notify(`Token applied: ${token.name}`);
      break;
    }

    // ── Save tokens ──
    case 'SAVE_TOKENS': {
      saveTokens(msg.tokens);
      figma.notify('Tokens saved to team library.');
      break;
    }

    // ── Generate Motion Guide ──
    case 'GENERATE_GUIDE': {
      await generateMotionGuide(msg.frameId);
      break;
    }

    // ── Select frame in canvas ──
    case 'SELECT_FRAME': {
      const node = figma.getNodeById(msg.frameId);
      if (node) {
        figma.currentPage.selection = [node as SceneNode];
        figma.viewport.scrollAndZoomIntoView([node as SceneNode]);
      }
      break;
    }

    // ── Highlight layer in canvas ──
    case 'SELECT_LAYER': {
      const node = figma.getNodeById(msg.layerId);
      if (node) {
        figma.currentPage.selection = [node as SceneNode];
      }
      break;
    }

    // ── Resize plugin window by tab ──
    case 'RESIZE': {
      figma.ui.resize(msg.width, msg.height);
      break;
    }

    // ── Export tokens as JSON ──
    case 'EXPORT_TOKENS': {
      const tokens = getTokens();
      figma.ui.postMessage({ type: 'TOKENS_EXPORT', json: JSON.stringify(tokens, null, 2) });
      break;
    }
  }
};

// ─────────────────────────────────────────
//  Listen for selection changes
// ─────────────────────────────────────────

figma.on('selectionchange', () => {
  const selected = figma.currentPage.selection[0];
  if (selected && (selected.type === 'FRAME' || selected.type === 'COMPONENT')) {
    figma.ui.postMessage({
      type: 'SELECTION_CHANGED',
      frameId: selected.id,
      frameName: selected.name,
    });
  }
});

// ─────────────────────────────────────────
//  Listen for document changes (design update detection)
// ─────────────────────────────────────────

figma.on('documentchange', (event) => {
  const relevantChanges = event.documentChanges.filter(
    c => c.type === 'CREATE' || c.type === 'DELETE' || c.type === 'PROPERTY_CHANGE'
  );
  if (relevantChanges.length > 0) {
    figma.ui.postMessage({ type: 'DESIGN_CHANGED', count: relevantChanges.length });
  }
});

// ─────────────────────────────────────────
//  Init
// ─────────────────────────────────────────

figma.showUI(__html__, { width: 960, height: 600, title: 'MotionBridge' });

// Initialize tokens if first time
const existing = figma.root.getSharedPluginData('motionbridge', KEY_TOKENS);
if (!existing) {
  saveTokens(ST_TOKENS);
}
